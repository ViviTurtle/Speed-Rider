

<?php
// connection to the database and start the session
require("./includes/common.php");
include("./includes/header.php");
// This variable will be used to re-display the user's username
$submitted_username = '';

// checks to determine whether the login form has been submitted
// If it has, then the login code is run, otherwise the form is displayed
if(!empty($_POST))
{


    // retreives the user's information from the database using username.
    $query = " 
            SELECT 
                USER_ID,
                USERNAME, 
                SALTED_HASH 
                
            FROM T_USER 
            WHERE 
                USERNAME = :username 
        ";

    // The parameter values
    $query_params = array(
        ':username' => $_POST['username']
    );

    try
    {
        // Execute the query against the database
        $stmt = $db->prepare($query);
        $result = $stmt->execute($query_params);
    }
    catch(PDOException $ex)
    {
        die("Failed to run query: " . $ex->getMessage());
    }


    $login_ok = false;

    // Retrieve the user data from the database.  If $row is false, then the username
    // they entered is not registered.
    $row = $stmt->fetch();
    if($row)
    {
        // Using the password submitted by the user and the salt stored in the database,
        // we now check to see whether the passwords match by hashing the submitted password
        // and comparing it to the hashed version already stored in the database.
        $check_password = hash('sha256', $_POST['password'] . $row['SALTED_HASH']);
        for($round = 0; $round < 65536; $round++)
        {
            $check_password = hash('sha256', $check_password . $row['SALTED_HASH']);
            echo hash('sha256', $check_password);
        }


    }

    // If the user logged in successfully, then we send them to the private members-only page
    // Otherwise, we display a login failed message and show the login form again
    if($login_ok)
    {
        unset($row['SALTED_HASH']);

        // This stores the user's data into the session at the index 'user'.

        $_SESSION['user'] = $row;

        // Redirect the user to the private members-only page.
        //   header("Location: private.php");
        // die("Redirecting to: private.php");
        header("Location: ./driver.php");;
    }
    else
    {
        echo '<br><br><br><br><h1>';
        echo '<h1> Wrong Password! </h1>';

    }
}

?>

<!-- Header -->
<header id="top" class="header">



    <section>

    <div class="container">
        <div class="col-lg-10 col-lg-offset-1">


            <div class="loginbox">
                <br>
                <br>
                    <img class="center-block img-responsive" src="img/logowhite.png">
                <p class="background-line"><span><h1>Sign in</h1></span></p>
                <form method="post" novalidate="">
                <input type="text" name="username" class="text-input fieldtop " placeholder="Username" value="" autofocus="">
                <input type="password" name="password" class="text-input fieldbottom" placeholder="Password" id="password">
                <!--
                <div class="squaredThree">
                    <input type="checkbox" value="None" id="squaredThree" name="check" hidden />
                    <h6 class="text-nowrap">Remember Me</h6>
                    <label for="squaredThree"></label>
                </div>-->
                 <p class="row"><button type="submit" class="btn btn-dark btn-group-lg">Login</button></p>

                </form>



                <span>•</span>
                <a href="" class="forgot-password">
                    Forgot Password?
                </a>
            </div>
        </div>

    </div>

    </section>

</header>

<!-- jQuery -->
<script src="./js/jquery-1.12.3.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="./js/bootstrap.min.js"></script>

<!-- Custom Theme JavaScript -->
<script>
    // Closes the sidebar menu
    $("#menu-close").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
    });

    // Opens the sidebar menu
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
    });

    // Scrolls to the selected menu item on the page
    $(function() {
        $('a[href*=#]:not([href=#])').click(function() {
            if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {

                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                if (target.length) {
                    $('html,body').animate({
                        scrollTop: target.offset().top
                    }, 1000);
                    return false;
                }
            }
        });
    });
</script>

</body>

</html>
